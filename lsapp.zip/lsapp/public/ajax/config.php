<?php
/* Database connection start */


$conn = mysqli_connect("localhost",DB_USERNAME, DB_PASSWORD) or die("Connection failed: " . mysqli_connect_error());

/* Database connection end */


?>