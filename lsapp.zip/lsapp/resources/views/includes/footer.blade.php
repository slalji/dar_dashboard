<footer>
    <div class="pull-right">
        <a href="https://selcom.net">Selcom</a>
    </div>
    <div class="clearfix"></div>
</footer>