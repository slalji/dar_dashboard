 <!-- Bootstrap -->
 <script src="./vendor/bootstrap/dist/js/bootstrap.min.js"></script>

<!-- FastClick -->
<script src="./vendor/fastclick/lib/fastclick.js"></script>
<!-- NProgress -->
<script src="./vendor/nprogress/nprogress.js"></script>
<!-- iCheck -->
<script src="./vendor/iCheck/icheck.min.js"></script>
<!-- Chart.js -->
<script src="./vendor/Chart.js/dist/Chart.min.js"></script>
   <!-- Flot -->
   <script src="./vendors/Flot/jquery.flot.js"></script>
<script src="./vendors/Flot/jquery.flot.pie.js"></script>
<script src="./vendors/Flot/jquery.flot.time.js"></script>
<script src="./vendors/Flot/jquery.flot.stack.js"></script>
<script src="./vendors/Flot/jquery.flot.resize.js"></script>
<script src="./vendors/Flot/jquery.flot.axislabels.js"></script>
<!-- Flot plugins -->
<script src="./vendors/flot.orderbars/js/jquery.flot.orderBars.js"></script>
<script src="./vendors/flot-spline/js/jquery.flot.spline.min.js"></script>
<script src="./vendors/Flot/flot.tooltip-master/js/jquery.flot.tooltip.source.js"></script>
<script src="./vendors/Flot/flot.tooltip-master/js/jquery.flot.tooltip.js"></script>


<!-- Datatables -->
<script src="./vendors/datatables.net/js/jquery.dataTables.min.js"></script>
<script src="./vendors/datatables.net-bs/js/dataTables.bootstrap.min.js"></script>
<script src="./vendors/datatables.net-buttons/js/dataTables.buttons.min.js"></script>
<script src="./vendors/datatables.net-buttons-bs/js/buttons.bootstrap.min.js"></script>
<script src="./vendors/datatables.net-buttons/js/buttons.flash.min.js"></script>
<script src="./vendors/datatables.net-buttons/js/buttons.html5.min.js"></script>
<script src="./vendors/datatables.net-buttons/js/buttons.print.min.js"></script>
<script src="./vendors/datatables.net-buttons/js/buttons.colVis.min.js"></script>
<script src="./vendors/datatables.net-fixedheader/js/dataTables.fixedHeader.min.js"></script>
<script src="./vendors/datatables.net-keytable/js/dataTables.keyTable.min.js"></script>
<script src="./vendors/datatables.net-responsive/js/dataTables.responsive.min.js"></script>
<script src="./vendors/datatables.net-responsive-bs/js/responsive.bootstrap.js"></script>
<script src="./vendors/datatables.net-scroller/js/dataTables.scroller.min.js"></script>
<script src="./vendors/jszip/dist/jszip.min.js"></script>
<script src="./vendors/pdfmake/build/pdfmake.min.js"></script>
<script src="./vendors/pdfmake/build/vfs_fonts.js"></script>
<!-- JS_MASK-->
<script src="./vendors/jquery_mask/dist/jquery.mask.min.js"></script>
<!-- Include Date Range Picker -->
<!-- Include Required Prerequisites -->
<script type="text/javascript" src="./vendors/moment/min/moment.min.js"></script>

<!-- Include Date Range Picker -->
<script type="text/javascript" src="./vendors/bootstrap-daterangepicker/daterangepicker.js"></script>

<link rel="stylesheet" type="text/css" href="./vendors/bootstrap-daterangepicker/daterangepicker.css" />
<!-- jQuery Smart Wizard -->
<script src="./vendors/jQuery-Smart-Wizard/js/jquery.smartWizard.js"></script><!-- jQuery Smart Wizard -->
<!-- jQuery Galic Persistant to localstorage -->
<script src="./vendors/garlicjs/dist/garlic.min.js"></script>

<script src="./build/js/custom.js"></script>

<script src="./app/js/smartwizard.js"></script>
