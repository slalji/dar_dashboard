<footer class="text-muted">
<div class="container">
<p class="float-right">
<a href="#">Back to top</a>
</p>
<p> &copy; Selcom 2018</p>
</div>
</footer>
