<!DOCTYPE html>
<html lang="en">
<head>
<?php echo $__env->make('layout.gentelella.head', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</head>
<body class="nav-md">
    <div class="container body">
      <div class="main_container">
        <div class="col-md-3 left_col">
          <div class="left_col scroll-view">
            <div class="navbar nav_title" style="border: 0;">
              <a href="index.php" class="site_title" style="background:#D9DEE4; "><img src="images/SELCOM-01.png" alt="Selcom"> <!--<span style="color:#2A3F54">Selcom</span>--></a>
            </div>

            <div class="clearfix"></div>        

<?php echo $__env->make('layout.gentelella.menu_profile', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<br />
<?php echo $__env->make('layout.gentelella.sidebar', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
</div>
</div>
<?php echo $__env->make('layout.gentelella.top_nav', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<div class="right_col" role="main">
<?php echo $__env->yieldContent('content'); ?>
</div>
    </div>
<?php echo $__env->make('layout.gentelella.footer', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>
<?php echo $__env->make('layout.gentelella.footer-scripts', array_except(get_defined_vars(), array('__data', '__path')))->render(); ?>

</body>
</html>
