<?php $__env->startSection('content'); ?>

    <div class="col-md-2 col-sm-4 col-xs-6 tile_stats_count"> 
    <?php $__currentLoopData = $tiles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $tile): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <span class="count"><i class="fa fa-wrench"></i> <?php echo e($tile->utility_code); ?></span>
    <span class="count_top"><?php echo e($tile->cnt); ?> </span>
    <span class="count_bottom"><i class="green"><?php echo e($tile->amnt); ?>/=</i> Tsh</span>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
   
    </div>
<?php $__env->stopSection(); ?>

