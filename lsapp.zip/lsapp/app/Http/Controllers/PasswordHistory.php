<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class PasswordHistory extends Controller
{
   /* protected function create(array $data)
    {
 
        $passwordHistory = PasswordHistory::create([
            'user_id' => $data['user_id'],           
            'password' =>$data['password'],
        ]);
 
         
        return $passwordHistory;
    }
    */
 
}
